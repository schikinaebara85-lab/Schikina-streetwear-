window.KT_DATA={
  talents:[
    {id:1,name:"Chris M.",sport:"Football",city:"Brazzaville",position:"Attaquant",age:18,tag:"U18"},
    {id:2,name:"Junior K.",sport:"Basketball",city:"Pointe-Noire",position:"Ailier",age:19,tag:"U20"},
    {id:3,name:"Sarah N.",sport:"Athlétisme",city:"Brazzaville",position:"Sprint",age:17,tag:"U18"},
    {id:4,name:"Merveille B.",sport:"Football",city:"Dolisie",position:"Milieu",age:20,tag:"Senior"},
    {id:5,name:"David L.",sport:"Boxe",city:"Pointe-Noire",position:"-67 kg",age:21,tag:"Senior"},
    {id:6,name:"Esther P.",sport:"Handball",city:"Brazzaville",position:"Arrière",age:18,tag:"U18"}
  ],
  opportunities:[
    {title:"Détection Football U18",org:"KONGO TALENTS",city:"Brazzaville",type:"Détection"},
    {title:"Camp de perfectionnement",org:"Académie partenaire",city:"Pointe-Noire",type:"Camp"},
    {title:"Test Athlétisme",org:"Club partenaire",city:"Brazzaville",type:"Test"}
  ],
  sports:["Football","Basketball","Athlétisme","Boxe","Handball","Volleyball","Judo"]
};