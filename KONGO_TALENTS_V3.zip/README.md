# KONGO TALENTS — V3

Prototype statique prêt pour GitHub + Netlify.

## Structure
- `index.html` : pages et sections principales
- `styles.css` : design responsive
- `data.js` : données de démonstration
- `app.js` : interactions, recherche, inscription, Ma Vision, rapports Scout
- `assets/images/` : images à ajouter plus tard

## Fonctionnalités V3
- Accueil
- Inscription athlète
- Profils et recherche de talents
- Opportunités
- Ma Vision
- Scouting + Rapport Scout
- FR / EN / ES
- Stockage local du prototype

## Déploiement Netlify
Le dossier racine du projet est celui qui contient `index.html`.
Aucune commande de build n'est nécessaire pour cette version statique.
